from flask_mail import Message
from . import mail

def send_activation_email(email):
    msg = Message('Activate Your Account', recipients=[email])
    msg.body = 'Click the link to activate your account.'
    mail.send(msg)

def send_admin_notification(parent_email, child_name):
    msg = Message('New Child Added', recipients=['admin@example.com'])
    msg.body = f'A new child named {child_name} has been added by {parent_email}.'
    mail.send(msg)
