from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from .models import db, Parent, Child
from .utils import send_activation_email, send_admin_notification
import threading
import time

bp = Blueprint('routes', __name__)

@bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    hashed_password = generate_password_hash(data['password'], method='sha256')
    new_parent = Parent(email=data['email'], password=hashed_password)
    db.session.add(new_parent)
    db.session.commit()
    send_activation_email(data['email'])
    return jsonify({'message': 'User registered! Check your email for the activation link.'}), 201

@bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    parent = Parent.query.filter_by(email=data['email']).first()
    if parent and check_password_hash(parent.password, data['password']):
        access_token = create_access_token(identity=parent.id)
        return jsonify(access_token=access_token), 200
    return jsonify({'message': 'Invalid credentials'}), 401

@bp.route('/profile', methods=['PUT'])
@jwt_required()
def update_profile():
    data = request.get_json()
    parent_id = get_jwt_identity()
    parent = Parent.query.get(parent_id)
    parent.first_name = data.get('first_name', parent.first_name)
    parent.last_name = data.get('last_name', parent.last_name)
    parent.age = data.get('age', parent.age)
    parent.address = data.get('address', parent.address)
    parent.city = data.get('city', parent.city)
    parent.country = data.get('country', parent.country)
    parent.pincode = data.get('pincode', parent.pincode)
    parent.profile_photo = data.get('profile_photo', parent.profile_photo)
    db.session.commit()
    return jsonify({'message': 'Profile updated successfully!'}), 200

@bp.route('/children', methods=['POST'])
@jwt_required()
def add_child():
    data = request.get_json()
    parent_id = get_jwt_identity()
    new_child = Child(name=data['name'], age=data['age'], parent_id=parent_id)
    db.session.add(new_child)
    db.session.commit()
    
    # Delay admin notification
    threading.Thread(target=delayed_admin_notification, args=(new_child.id,)).start()
    
    return jsonify({'message': 'Child added successfully!'}), 201

@bp.route('/children', methods=['GET'])
@jwt_required()
def list_children():
    parent_id = get_jwt_identity()
    children = Child.query.filter_by(parent_id=parent_id).all()
    children_list = [{'id': child.id, 'name': child.name, 'age': child.age, 'created_at': child.created_at} for child in children]
    return jsonify(children_list), 200

@bp.route('/children/<int:child_id>', methods=['PUT'])
@jwt_required()
def edit_child(child_id):
    data = request.get_json()
    child = Child.query.get_or_404(child_id)
    child.name = data.get('name', child.name)
    child.age = data.get('age', child.age)
    db.session.commit()
    return jsonify({'message': 'Child updated successfully!'}), 200

def delayed_admin_notification(child_id):
    time.sleep(300)
    child = Child.query.get(child_id)
    parent = Parent.query.get(child.parent_id)
    send_admin_notification(parent.email, child.name)
