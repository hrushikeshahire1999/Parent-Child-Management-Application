from . import db
from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship
import datetime

class Parent(db.Model):
    id = Column(Integer, primary_key=True)
    email = Column(String(120), unique=True, nullable=False)
    password = Column(String(128), nullable=False)
    first_name = Column(String(50))
    last_name = Column(String(50))
    age = Column(Integer)
    address = Column(String(120))
    city = Column(String(50))
    country = Column(String(50))
    pincode = Column(String(20))
    profile_photo = Column(String(200))
    children = relationship('Child', backref='parent', lazy=True)

class Child(db.Model):
    id = Column(Integer, primary_key=True)
    name = Column(String(50), nullable=False)
    age = Column(Integer, nullable=False)
    parent_id = Column(Integer, ForeignKey('parent.id'), nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
